from __future__ import annotations

import torch

from source.omy.vision.tasks.common.omy_base_vision_env import OmyBaseVisionEnv
from source.omy.vision.tasks.common.omy_vision_env_cfg import OmyVisionEnvCfg


class OmyGraspVisionEnv(OmyBaseVisionEnv):
    cfg: OmyVisionEnvCfg

    def _get_rewards(self) -> torch.Tensor:
        t = self._get_common_terms()
        grasp_bonus = t['is_grasping'].float() * 5.0
        alignment_score = torch.exp(-60.0 * t['xy_dist']**2) * torch.exp(-60.0 * t['z_dist']**2)
        close_reward = alignment_score * torch.clamp(t['gripper_joint'], min=0.0) * t['aligned'].float()
        pre_grasp_reward = t['pre_grasp_ready'].float() * 2.0
        obj_height = t['obj_pos'][:, 2]
        lift_reward = torch.clamp(obj_height - (self.cfg.object_size_xyz[2] * 0.5), min=0.0) * (1.0 + 2.0 * t['is_grasping'].float()) * 10.0
        action_penalty = torch.sum(self.actions[:, :6] ** 2, dim=-1) * 0.001
        reward = 0.2 * t['approach_reward'] + 0.2 * t['xy_align_reward'] + 0.2 * t['z_align_reward'] + 2.5 * close_reward + 0.5 * pre_grasp_reward + 0.5 * grasp_bonus + 0.1 * lift_reward + 0.25 * t['vision_ok'].float() - 0.15 * t['vision_stale'].float() - torch.clamp(self.vision_miss_count.float() * 0.01, max=0.25) - action_penalty
        self.reward_log = {'success_rate': float(t['is_grasping'].float().mean()), 'vision_ok': float(t['vision_ok'].float().mean()), 'vision_stale': float(t['vision_stale'].float().mean())}
        self.extras['log'] = dict(self.reward_log)
        return reward
