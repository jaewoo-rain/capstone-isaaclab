from __future__ import annotations

import math
from typing import Iterable

import numpy as np


def _as_np(x) -> np.ndarray:
    if isinstance(x, np.ndarray):
        return x.astype(np.float32)

    # torch tensor
    try:
        import torch
        if isinstance(x, torch.Tensor):
            return x.detach().cpu().numpy().astype(np.float32)
    except Exception:
        pass

    # CameraIntrinsics 같은 객체 처리
    if hasattr(x, "fx") and hasattr(x, "fy") and hasattr(x, "cx") and hasattr(x, "cy"):
        return np.array([
            [float(x.fx), 0.0, float(x.cx)],
            [0.0, float(x.fy), float(x.cy)],
            [0.0, 0.0, 1.0],
        ], dtype=np.float32)

    # dict 형태 처리
    if isinstance(x, dict) and all(k in x for k in ["fx", "fy", "cx", "cy"]):
        return np.array([
            [float(x["fx"]), 0.0, float(x["cx"])],
            [0.0, float(x["fy"]), float(x["cy"])],
            [0.0, 0.0, 1.0],
        ], dtype=np.float32)

    return np.asarray(x, dtype=np.float32)


def _quat_wxyz_to_rotmat(q_wxyz: np.ndarray) -> np.ndarray:
    q = _as_np(q_wxyz).reshape(4)
    w, x, y, z = q
    n = np.linalg.norm(q)
    if n < 1e-8:
        return np.eye(3, dtype=np.float32)
    w, x, y, z = q / n

    return np.array([
        [1.0 - 2.0 * (y * y + z * z), 2.0 * (x * y - z * w), 2.0 * (x * z + y * w)],
        [2.0 * (x * y + z * w), 1.0 - 2.0 * (x * x + z * z), 2.0 * (y * z - x * w)],
        [2.0 * (x * z - y * w), 2.0 * (y * z + x * w), 1.0 - 2.0 * (x * x + y * y)],
    ], dtype=np.float32)


def _world_to_camera(world_xyz: np.ndarray, cam_pos_w: np.ndarray, cam_quat_wxyz: np.ndarray) -> np.ndarray:
    """
    world point -> camera point
    camera pose is given in world frame.
    """
    world_xyz = _as_np(world_xyz).reshape(3)
    cam_pos_w = _as_np(cam_pos_w).reshape(3)
    cam_quat_wxyz = _as_np(cam_quat_wxyz).reshape(4)

    r_wc = _quat_wxyz_to_rotmat(cam_quat_wxyz)   # camera -> world
    r_cw = r_wc.T                                # world -> camera
    t = world_xyz - cam_pos_w
    cam_xyz = r_cw @ t
    return cam_xyz.astype(np.float32)


def _project_camera_to_image(cam_xyz: np.ndarray, K: np.ndarray) -> tuple[float, float] | None:
    x, y, z = cam_xyz.tolist()
    if z <= 1e-6:
        return None
    fx = float(K[0, 0])
    fy = float(K[1, 1])
    cx = float(K[0, 2])
    cy = float(K[1, 2])

    u = fx * x / z + cx
    v = fy * y / z + cy
    return float(u), float(v)


def _approx_bbox_from_center_and_size(
    center_world: np.ndarray,
    size_xyz: np.ndarray,
    cam_pos_w: np.ndarray,
    cam_quat_wxyz: np.ndarray,
    K: np.ndarray,
    img_w: int,
    img_h: int,
) -> list[float] | None:
    """
    안정성 우선:
    3D 박스 8개 꼭짓점 투영 대신
    물체 중심점 + 실제 크기 + depth로 대략적인 2D bbox 생성
    """
    center_world = _as_np(center_world).reshape(3)
    size_xyz = _as_np(size_xyz).reshape(3)

    cam_center = _world_to_camera(center_world, cam_pos_w, cam_quat_wxyz)
    uv = _project_camera_to_image(cam_center, K)
    if uv is None:
        return None

    u, v = uv
    _, _, z = cam_center.tolist()
    if z <= 1e-6:
        return None

    fx = float(K[0, 0])
    fy = float(K[1, 1])

    # depth 기준으로 화면상 크기 근사
    # x축: 물체 가로, y축: 물체 세로/높이 중 큰 값 사용해서 일단 넉넉하게
    sx, sy, sz = size_xyz.tolist()
    box_w_px = fx * max(sx, sy) / z
    box_h_px = fy * max(sy, sz) / z

    # 너무 작거나 너무 큰 경우 보호
    box_w_px = max(box_w_px, 4.0)
    box_h_px = max(box_h_px, 4.0)

    x1 = u - box_w_px / 2.0
    y1 = v - box_h_px / 2.0
    x2 = u + box_w_px / 2.0
    y2 = v + box_h_px / 2.0

    # 화면과 조금이라도 겹치면 살림
    if x2 < 0 or y2 < 0 or x1 >= img_w or y1 >= img_h:
        return None

    x1 = float(np.clip(x1, 0, img_w - 1))
    y1 = float(np.clip(y1, 0, img_h - 1))
    x2 = float(np.clip(x2, 0, img_w - 1))
    y2 = float(np.clip(y2, 0, img_h - 1))

    if x2 - x1 < 2 or y2 - y1 < 2:
        return None

    return [x1, y1, x2, y2]


def compute_annotations_from_sim(
    positions_w: Iterable,
    quats_wxyz: Iterable,
    sizes_xyz: Iterable,
    class_ids: Iterable[int],
    cam_pos_w,
    cam_quat_wxyz,
    K,
    img_w: int,
    img_h: int,
) -> list[list[float]]:
    """
    반환 형식:
    [
      [class_id, x1, y1, x2, y2],
      ...
    ]
    """
    cam_pos_w = _as_np(cam_pos_w)
    cam_quat_wxyz = _as_np(cam_quat_wxyz)
    K = _as_np(K)

    labels: list[list[float]] = []

    for pos_w, quat_wxyz, size_xyz, cls_id in zip(positions_w, quats_wxyz, sizes_xyz, class_ids):
        pos_w = _as_np(pos_w).reshape(3)
        size_xyz = _as_np(size_xyz).reshape(3)

        bbox = _approx_bbox_from_center_and_size(
            center_world=pos_w,
            size_xyz=size_xyz,
            cam_pos_w=cam_pos_w,
            cam_quat_wxyz=cam_quat_wxyz,
            K=K,
            img_w=img_w,
            img_h=img_h,
        )

        if bbox is None:
            continue

        labels.append([float(cls_id), *bbox])

    return labels


def xyxy_to_yolo_normalized(label_xyxy: list[float], img_w: int, img_h: int) -> str:
    cls_id, x1, y1, x2, y2 = label_xyxy
    x1 = float(x1)
    y1 = float(y1)
    x2 = float(x2)
    y2 = float(y2)

    cx = ((x1 + x2) * 0.5) / float(img_w)
    cy = ((y1 + y2) * 0.5) / float(img_h)
    w = (x2 - x1) / float(img_w)
    h = (y2 - y1) / float(img_h)

    cx = min(max(cx, 0.0), 1.0)
    cy = min(max(cy, 0.0), 1.0)
    w = min(max(w, 0.0), 1.0)
    h = min(max(h, 0.0), 1.0)

    return f"{int(cls_id)} {cx:.6f} {cy:.6f} {w:.6f} {h:.6f}"